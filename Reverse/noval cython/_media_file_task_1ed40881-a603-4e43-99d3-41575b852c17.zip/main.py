import check_secret
flag = input("input your flag:")
if check_secret.check(flag):
    print(":)")
else:
    print(":(")