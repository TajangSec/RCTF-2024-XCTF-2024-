const express = require("express");
const mysql = require("mysql");
const app = express();
const port = 3000;

const db = mysql.createConnection({
  host: "db",
  user: "user",
  password: "password",
  database: "test",
});

db.connect((err) => {
  if (err) {
    console.error("Error connecting to the database:", err);
    return;
  }
  console.log("Connected to the MySQL database.");
});

db.query(
  "CREATE TABLE IF NOT EXISTS key1 (id INT AUTO_INCREMENT PRIMARY KEY,love_key VARCHAR(255) NOT NULL)"
);
db.query(
  "INSERT INTO key1 (love_key) VALUES('RCTF{key1')"
);
db.end((err) => {
  if (err) throw err;
  console.log("Disconnected from MySQL database");
});
