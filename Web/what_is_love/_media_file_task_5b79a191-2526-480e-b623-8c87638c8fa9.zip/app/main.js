const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const mysql = require("mysql");
const auth = require("./auth");

const app = express();
const port = 3000;
const key2 = "_key2}";
const db = mysql.createPool({
  host: "db",
  user: "user",
  password: "password",
  database: "test",
});

class My_lover {
  constructor() {
    this.username = process.env.LOVER || "lover";
    this.love_time = parseInt(process.env.LOVE_TIME, 10) || 30;
  }
}

const my_lover = new My_lover(); // new one lover, OvO

const blacklist = [
  "SELECT",
  "CREATE",
  "TABLE",
  "DATABASE",
  "IF",
  "\\(",
  "\\)",
  "INSERT",
  "UPDATE",
  "DELETE",
  "AND",
  "OR",
  "\\.\\./",
  "\\./",
  "UNION",
  "INTO",
  "LOAD_FILE",
  "OUTFILE",
  "DUMPFILE",
  "SUB",
  "HEX",
  "NOW",
  "CURRENT_TIMESTAMP",
  "GETDATE",
  "SLEEP",
  "SUBSTRING",
  "MID",
  "LEFT",
  "RIGHT",
  "ASCII",
  "CHAR",
  "REPEAT",
  "REPLICATE",
  "LIKE",
  "%",
];

function isSafe(input) {
  const pattern = new RegExp(blacklist.join("|"), "i");
  return !pattern.test(input);
}

app.set("view engine", "ejs");

app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.render("key1");
});

app.get("/key2", (req, res) => {
  res.render("key2");
});

app.get("/check", (req, res) => {
  res.render("check");
});

app.post("/key1", (req, res) => {
  const { key1 } = req.body;
  if (key1.length > 52 || !isSafe(key1)) {
    return res.send("love waf");
  }
  let res1 = `SELECT * FROM key1 WHERE love_key = '${key1}'`;
  db.query(`SELECT * FROM key1 WHERE love_key = '${key1}'`, (err, results) => {
    if (err) {
      res.send("error");
    } else if (results.length > 0) {
      res.send("success");
    } else {
      res.send("wrong");
    }
  });
});

app.post("/key2", (req, res) => {
  let { username, love_time } = req.body;
  let userInfo = {};
  userInfo.username = username;
  userInfo.love_time = Number(love_time);
  if (userInfo.love_time < 10000 || typeof userInfo.love_time !== "number") {
    res.send(
      "There was once a sincere love in front of me, I didn't cherish it, and I regretted it when I lost it, and the most painful thing in the world is nothing more than this. If God could give me a chance to start over, I would say three words to that girl: I love you. If I had to put a deadline on this love, I would say 10,000 years."
    );
  }
  let have_lovers = false;
  if (
    userInfo.username === my_lover.username &&
    userInfo.love_time === my_lover.love_time
  ) {
    have_lovers = true;
  }
  let token = auth.createToken({
    username: userInfo.username,
    love_time: userInfo.love_time,
    have_lovers: have_lovers,
  });
  res.send(`give your a love token:${token}`);
});

app.post("/check", (req, res) => {
  let { love_token } = req.body;
  const [userinfo, err] = auth.decodeToken(love_token);
  if (err) {
    res.send("error");
    return;
  }
  if (userinfo.have_lovers) {
    res.send(`your key2 is ${key2}`);
  } else {
    res.send("your have not lover");
  }
});

app.listen(port, () => {
  console.log(`http://localhost:${port}`);
});
