const crypto = require("crypto");

const secret = crypto.randomBytes(128);
const hash = (data) => crypto.createHash("sha256").update(data).digest("hex");


const createToken = (userinfo) => {
  const saltedSecret =
    parseInt(Buffer.from(secret).readBigUInt64BE()) +
    parseInt(userinfo.love_time);
  const data = JSON.stringify(userinfo);
  return (
    Buffer.from(data).toString("base64") + "." + hash(`${data}:${saltedSecret}`)
  );
};

const decodeToken = (token) => {
  if (!token) return [null, "invalid token"];
  const [dataHex, signature] = token.split(".");
  const data = Buffer.from(dataHex, "base64").toString();
  const userinfo = JSON.parse(data);
  const saltedSecret =
    parseInt(Buffer.from(secret).readBigUInt64BE()) +
    parseInt(userinfo.love_time);

  if (hash(`${data}:${saltedSecret}`) !== signature)
    return [null, "invalid token: it is not you"];
  return [userinfo, null];
};


module.exports = {
  createToken,
  decodeToken,
};
