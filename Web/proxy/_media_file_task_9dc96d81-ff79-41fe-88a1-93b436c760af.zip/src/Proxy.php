<?php
class Proxy{
    private $ch;
    public $body;

    public function __construct(){
        $this->ch = curl_init() or die(curl_error());
        //curl_setopt($this->ch, CURLOPT_PROTOCOLS, CURLPROTO_HTTP | CURLPROTO_HTTPS);
    }

    public function SendRequest($URL)
    {
        $ret = TRUE;
        if(isset($_SERVER['HTTPS'])){
            if($_SERVER['HTTPS'] == 'off')
            {
                $http = 'http://';
            }
            else {
                $http = 'https://';
            }
        }
        else
        {
            $http = 'http://';
        }
        $http .= $_SERVER['SERVER_NAME'].':'.$_SERVER['SERVER_PORT'];
        curl_setopt($this->ch, CURLOPT_URL, $http.$URL);
        curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, 1);
        try{
            $this->body = curl_exec($this->ch);
        } catch (Exception $ex) {
            return FALSE;
        }
        return TRUE;
    }
}
