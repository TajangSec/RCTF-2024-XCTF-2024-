<?php
class Db{
    private $dm_handler;

    public function __construct($dm_conn = 'sqlite:data.db'){
        $this->dm_handler = new PDO($dm_conn);
        $this->dm_handler->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function execMultiSQL($arysql){
        try{
            $this->dm_handler->beginTransaction();
            foreach($arysql as $asql){
                $this->dm_handler->exec($asql);
            }
            $this->dm_handler->commit();
            return TRUE;
        }
        catch(PDOException $exception) {
            $this->dm_handler->rollBack();
            return FALSE;
        }
    }
}