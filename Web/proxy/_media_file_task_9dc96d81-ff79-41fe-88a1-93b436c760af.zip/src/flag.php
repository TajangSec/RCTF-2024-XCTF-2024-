<?php
$flag = 'flag{fake_flag}';