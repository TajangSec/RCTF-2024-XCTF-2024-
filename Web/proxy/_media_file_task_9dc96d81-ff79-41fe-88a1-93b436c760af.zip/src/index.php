<?php
require('Db.php');
require('Proxy.php');
$BE = $_GET['BE'] ?? 'flag';
$URL = '/'.$BE.'.php';
$ProxyObj = new Proxy();
if($ProxyObj->SendRequest($URL))
{
    $DbObj = new Db();
    $arysql = array();
    $sess = md5($_SERVER['REMOTE_ADDR']);
    $arysql[] = "INSERT OR REPLACE INTO CacheMain VALUES ('".$sess."', ".time().")";
    $arysql[] = "INSERT INTO CacheDetail VALUES ('".$sess."', '".$BE."')";
    $arysql[] = "CREATE TABLE Cache_".$sess."_".$BE." (t TEXT)";
    $arysql[] = "INSERT INTO Cache_".$sess."_".$BE." VALUES('".$ProxyObj->body."')";
    $DbObj->execMultiSQL($arysql);
}
