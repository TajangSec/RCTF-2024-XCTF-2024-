1. 
```bash
docker build -t "dwebp" . (注意最后的点)
```

2. 
```bash
docker run -d -p "0.0.0.0:9999:9999" -h "dwebp" --name="dwebp" dwebp 
```

`pub_port` 替换成你想要开放给选手的端口

