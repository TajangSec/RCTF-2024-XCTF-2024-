#!/bin/sh
export WASMTIME_NEW_CLI=0
export FLAG=$(cat flag)
./wasmtime run  --allow-precompiled  --disable-cache --env FLAG=$FLAG  ./minesweeper
