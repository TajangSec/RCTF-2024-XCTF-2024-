from random import getrandbits, randint
from Crypto.Util.number import getPrime, isPrime, inverse
from hashlib import sha1
import signal


def gen(l, n):
    q = getPrime(l)
    while True:
        t = getrandbits(n - l)
        p = t * q + 1
        if isPrime(p):
            break
    h = randint(1, p - 1)
    g = pow(h, t, p)
    x = randint(1, q)
    y = pow(g, x, p)
    return (p, q, g, y), x


def gen_ephemeral_key(k, lsb, msb):
    return msb << (k + lsb.bit_length()) | getrandbits(k) << lsb.bit_length() | lsb


def sign(pubkey, x, msg, lsb, msb):
    p, q, g, y = pubkey
    k = gen_ephemeral_key(150, lsb, msb)
    r = pow(g, k, p) % q
    Hm = int(sha1(msg).hexdigest(), 16)
    s = (Hm + x * r) * inverse(k, q) % q
    return (r, s)


def verify(pubkey, sig, msg):
    p, q, g, y = pubkey
    r, s = sig
    if not 0 < r < q or not 0 < s < q:
        return False
    w = inverse(s, q)
    Hm = int(sha1(msg).hexdigest(), 16)
    u1 = Hm * w % q
    u2 = r * w % q
    v = pow(g, u1, p) * pow(y, u2, p) % p % q
    return v == r


signal.alarm(900)
with open("flag.txt", "r") as f:
    flag = f.read()

l, n = 160, 1024
pub, x = gen(l, n)
print("your pubKey: {}".format(pub))
msb = getrandbits(8)
lsb = getrandbits(2)

menu = """
[1] sign message
[2] verify signature
"""

for i in range(20):
    print(menu)
    op = int(input(">").strip())
    if op == 1:
        msg = input("Which message to sign?: ").strip().encode()
        if msg == b"get flag":
            print("I'm afraid I can't do that.")
            break
        else:
            sig = sign(pub, x, msg, lsb, msb)
            print(f"Signature: {sig}")
    elif op == 2:
        msg = input("Which message to verify?: ").strip().encode()
        r = int(input("r:").strip())
        s = int(input("s:").strip())
        v = verify(pub, (r, s), msg)
        if v and msg == b"get flag":
            print(flag)
        else:
            print(v)
    else:
        print("Invalid option")
