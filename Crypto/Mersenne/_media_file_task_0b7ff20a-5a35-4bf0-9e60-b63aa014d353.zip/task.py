from random import randint
from Crypto.Util.number import inverse, bytes_to_long
from math import gcd, sqrt
from hashlib import sha1


def random_number(n, h):
    a = 0
    bit_mask = 1 << (n - 1)
    a |= bit_mask
    for i in range(h - 1):
        bit_mask = 1 << randint(0, n)
        while a & bit_mask:
            bit_mask = 1 << randint(0, n)
        a |= bit_mask
    return a


def gen_key(n, w, xi1, xi2):
    bf = int(n * xi1)
    bg = int(n * xi2)
    p = 2**n - 1
    f = random_number(bf, w)
    g = random_number(bg, w)
    while gcd(f, g) != 1:
        g = random_number(bg, w)
    h = inverse(g, p) * f % p
    return p, f, g, h


with open("flag.txt", "rb") as f:
    flag = f.read()

assert sha1(flag).hexdigest() == "e502325ed9e16cc79539e64bf802bb4069908544"

flag = bin(bytes_to_long(flag))[2:].zfill(len(flag) * 8)

s = []
for i in flag:
    s.append(int(i))

n = 607
w = int(sqrt(n) // 2)
xi1 = 0.5
xi2 = 0.5

for i in s:
    p, f, g, h = gen_key(n, w, xi1, xi2)
    a = random_number(n, w)
    b = random_number(n, w)
    t = (-1) ** i
    c = t * (a * h + b) % p
    print(c, h)
